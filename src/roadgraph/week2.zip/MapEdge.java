package roadgraph;

import geography.GeographicPoint;


//This class represents the Edges in the map
 class MapEdge {
	
	GeographicPoint point1;
	GeographicPoint point2;
	String roadName;
	String roadType;
	double length;
	
	public MapEdge(GeographicPoint point1,GeographicPoint point2, 
			String roadName,String roadType, double length){
		
		this.point1=point1;
		this.point2=point2;
		this.roadName=roadName;
		this.roadType=roadType;
		this.length=length;
		
	}

	public GeographicPoint getPoint1() {
		return point1;
	}

	public GeographicPoint getPoint2() {
		return point2;
	}

	public String getRoadName() {
		return roadName;
	}

	public String getRoadType() {
		return roadType;
	}

	public double getLength() {
		return length;
	}
	
	
	
	

}
